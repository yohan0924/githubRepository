package kr.co.myshop2.mapper;

import kr.co.myshop2.vo.MemberVo;

public interface MemberMapper {
	
	public void memberJoin_ok(MemberVo mvo);

}
