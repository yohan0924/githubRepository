package kr.co.myshop2.mapper;

import kr.co.myshop2.vo.MemberVo;

public interface LoginMapper {
	
	public MemberVo login_ok(MemberVo mvo);
	
	public int userid_check(String userid);
	
	public String find_email(String email);
	
	
}
