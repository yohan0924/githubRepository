package kr.co.myshop2.mapper;

import java.util.ArrayList;

import kr.co.myshop2.vo.BaesongVo;
import kr.co.myshop2.vo.BaesongjiVo;
import kr.co.myshop2.vo.BigVo;
import kr.co.myshop2.vo.ListVo;
import kr.co.myshop2.vo.MemberVo;
import kr.co.myshop2.vo.MiddleVo;
import kr.co.myshop2.vo.ProductVo;
import kr.co.myshop2.vo.SmallVo;

public interface ProductMapper {

	public ArrayList<BigVo> getBig();
	
	public ArrayList<MiddleVo> updateMiddle(String bigcode);
	
	public ArrayList<SmallVo> updateSmall(String bigmiddlecode);
	
	public void product_ok(ProductVo pvo);
	
	public int getCode(String pcode);
	
	public ArrayList<ProductVo> plist(String pcode);
	
	public void list(ProductVo pvo);
	
	public MemberVo getMember(String userid);
	
	public ArrayList<ListVo> baeCheck(String userid);
	
	public ArrayList<ProductVo> gumaelist(String userid);
	
	public BaesongjiVo showBaesongji(String userid);
	
	public void baesongji(BaesongjiVo bvo);
	
	public void del(String title);
	
	public ArrayList<ListVo> mylist(String userid);
	
	public ArrayList<ListVo> confirm(String userid);
	
	
	
}
