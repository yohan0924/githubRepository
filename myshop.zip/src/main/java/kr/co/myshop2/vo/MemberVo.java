package kr.co.myshop2.vo;

public class MemberVo {
	
	private int yy, mm, dd, gender;
	private String userid, pwd, name, email, writeday, phone;
	
	public int getGender()
	{
		return gender;
	}
	public void setGender(int gender)
	{
		this.gender = gender;
	}
	public String getPhone()
	{
		return phone;
	}
	public void setPhone(String phone)
	{
		this.phone = phone;
	}
	public String getWriteday()
	{
		return writeday;
	}
	public void setWriteday(String writeday)
	{
		this.writeday = writeday;
	}
	public int getYy()
	{
		return yy;
	}
	public void setYy(int yy)
	{
		this.yy = yy;
	}
	public int getMm()
	{
		return mm;
	}
	public void setMm(int mm)
	{
		this.mm = mm;
	}
	public int getDd()
	{
		return dd;
	}
	public void setDd(int dd)
	{
		this.dd = dd;
	}
	
	public String getUserid()
	{
		return userid;
	}
	public void setUserid(String userid)
	{
		this.userid = userid;
	}
	public String getPwd()
	{
		return pwd;
	}
	public void setPwd(String pwd)
	{
		this.pwd = pwd;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	

}
