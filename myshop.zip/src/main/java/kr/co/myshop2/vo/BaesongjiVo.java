package kr.co.myshop2.vo;

public class BaesongjiVo {
	
	private int phone, zipcode;
	private String userid, baesongname, name, address, address_etc;
	public int getPhone()
	{
		return phone;
	}
	public void setPhone(int phone)
	{
		this.phone = phone;
	}
	public int getZipcode()
	{
		return zipcode;
	}
	public void setZipcode(int zipcode)
	{
		this.zipcode = zipcode;
	}
	public String getUserid()
	{
		return userid;
	}
	public void setUserid(String userid)
	{
		this.userid = userid;
	}
	public String getBaesongname()
	{
		return baesongname;
	}
	public void setBaesongname(String baesongname)
	{
		this.baesongname = baesongname;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getAddress()
	{
		return address;
	}
	public void setAddress(String address)
	{
		this.address = address;
	}
	public String getAddress_etc()
	{
		return address_etc;
	}
	public void setAddress_etc(String address_etc)
	{
		this.address_etc = address_etc;
	}

}
