package kr.co.myshop2.vo;

public class ProductVo {

	private int id, price, su, baesong, baeday;
	private String pcode, pimg, title, userid;
	public String getUserid()
	{
		return userid;
	}
	public void setUserid(String userid)
	{
		this.userid = userid;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public int getPrice()
	{
		return price;
	}
	public void setPrice(int price)
	{
		this.price = price;
	}
	public int getSu()
	{
		return su;
	}
	public void setSu(int su)
	{
		this.su = su;
	}
	public int getBaesong()
	{
		return baesong;
	}
	public void setBaesong(int baesong)
	{
		this.baesong = baesong;
	}
	public int getBaeday()
	{
		return baeday;
	}
	public void setBaeday(int baeday)
	{
		this.baeday = baeday;
	}
	public String getPcode()
	{
		return pcode;
	}
	public void setPcode(String pcode)
	{
		this.pcode = pcode;
	}
	public String getPimg()
	{
		return pimg;
	}
	public void setPimg(String pimg)
	{
		this.pimg = pimg;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	
}
