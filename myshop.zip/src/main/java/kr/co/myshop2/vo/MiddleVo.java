package kr.co.myshop2.vo;

public class MiddleVo {

	private int id;
	private String code, name, bigcode;
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getCode()
	{
		return code;
	}
	public void setCode(String code)
	{
		this.code = code;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getBigcode()
	{
		return bigcode;
	}
	public void setBigcode(String bigcode)
	{
		this.bigcode = bigcode;
	}
}
