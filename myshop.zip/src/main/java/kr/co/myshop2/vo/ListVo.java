package kr.co.myshop2.vo;

public class ListVo {
	
	private int price, su;
	private String pcode, pimg, title, userid;
	public int getPrice()
	{
		return price;
	}
	public void setPrice(int price)
	{
		this.price = price;
	}
	public int getSu()
	{
		return su;
	}
	public void setSu(int su)
	{
		this.su = su;
	}
	public String getPcode()
	{
		return pcode;
	}
	public void setPcode(String pcode)
	{
		this.pcode = pcode;
	}
	public String getPimg()
	{
		return pimg;
	}
	public void setPimg(String pimg)
	{
		this.pimg = pimg;
	}
	public String getTitle()
	{
		return title;
	}
	public void setTitle(String title)
	{
		this.title = title;
	}
	public String getUserid()
	{
		return userid;
	}
	public void setUserid(String userid)
	{
		this.userid = userid;
	}

}
