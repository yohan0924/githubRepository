package kr.co.myshop2.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.myshop2.service.LoginService;
import kr.co.myshop2.vo.MemberVo;

@Controller
public class LoginController {

	@Autowired
	@Qualifier("ls")
	private LoginService service;

	@RequestMapping("login/login")
	public String login(HttpServletRequest request, Model model)
	{
		return service.login(request, model);
	}
	
	@RequestMapping("login/login_ok")
	public String login_ok
	(MemberVo mvo, HttpSession session)
	{
		return service.login_ok(mvo, session);
	}
	
	@RequestMapping("login/userid_check")
	public void userid_check
	(HttpServletRequest request, PrintWriter out)
	{
		service.userid_check(request, out);
	}
	
	@RequestMapping("/logout")
	public String logout
	(HttpSession session)
	{
		return service.logout(session);
	}
	
	@RequestMapping("/login/findMyId")
	public String findMyId
	(HttpSession session)
	{
		return "/login/findMyId";
	}
	
	@RequestMapping("/login/find_email")
	public void find_email
	(HttpServletRequest request, Model model, PrintWriter out)
	{
		service.find_email(request, model, out);
	}
	

}
