package kr.co.myshop2.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.myshop2.service.MemberService;
import kr.co.myshop2.vo.MemberVo;

@Controller
public class MemberController {
	
	@Autowired
	@Qualifier("ms")
	private MemberService service;
	
	@RequestMapping("/login/memberJoin")
	public String memberJoin(HttpServletRequest request, Model model)
	{
		return service.memberJoin(request, model);
	}
	
	@RequestMapping("/login/memberJoin_ok")
	public String memberJoin_ok(MemberVo mvo)
	{
		return service.memberJoin_ok(mvo);
	}

	
}
