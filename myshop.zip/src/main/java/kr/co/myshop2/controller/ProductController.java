package kr.co.myshop2.controller;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.myshop2.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	@Qualifier("ps")
	private ProductService service;
	
	@RequestMapping("/product/product")
	public String product(Model model)
	{
		return service.product(model);
	}

	@RequestMapping("/product/updateMiddle")
	public void updateMiddle(HttpServletRequest request, PrintWriter out)
	{
		service.updateMiddle(request, out);
	}
	
	@RequestMapping("/product/updateSmall")
	public void updateSmall
	(HttpServletRequest request, PrintWriter out)
	{
		service.updateSmall(request, out);
	}
	
	@RequestMapping("/product/product_ok")
	public String product_ok
	(HttpServletRequest request) throws Exception
	{
		return service.product_ok(request);
	}
	
	@RequestMapping("/product/getCode")
	public void getCode
	(HttpServletRequest request, PrintWriter out)
	{
		service.getCode(request, out);
	}
	
	@RequestMapping("/product/plist")
	public String plist
	(HttpServletRequest request, Model model)
	{
		return service.plist(request, model);
	}
	
	@RequestMapping("/product/list")
	public String list
	(HttpServletRequest request, Model model, PrintWriter out, HttpSession session)
	{
		return service.list(request, model, out, session);
				
	}
	
	@RequestMapping("/product/gumae")
	public String gumae
	(HttpServletRequest request, Model model, HttpSession session)
	{
		return service.gumae(request, model, session);
	}
	
	@RequestMapping("/product/confirm")
	public String confirm
	(HttpServletRequest request, HttpSession session, Model model, PrintWriter out)
	{
		return service.confirm(request, session, model, out);
	}
	
	@RequestMapping("/product/baeCheck")
	public String baeCheck
	(HttpServletRequest request, HttpSession session, Model model)
	{
		return service.baeCheck(request, session, model);
	}

	@RequestMapping("/product/gumaelist")
	public String gumelist
	(HttpServletRequest request, Model model, HttpSession session)
	{
		return service.gumaelist(request, model ,session);
	}
	
	@RequestMapping("/product/showBaesongji")
	public String showBaesongji
	(HttpServletRequest request, HttpSession session, Model model)
	{
		return service.showBaesongji(request, session, model);
	}
	
	@RequestMapping("/product/baesongChange")
	public String basongChange()
	{
		return "/product/baesongChange";
	}
	
	@RequestMapping("/product/baesongji")
	public String baesongChange
	(HttpServletRequest request, HttpSession session)
	{
		return service.baesongji(request, session);
	}
	
	@RequestMapping("/product/del")
	public String del
	(HttpServletRequest request)
	{
		return service.del(request);
	}
}
