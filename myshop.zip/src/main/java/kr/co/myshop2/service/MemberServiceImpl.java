package kr.co.myshop2.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.myshop2.mapper.MemberMapper;
import kr.co.myshop2.vo.MemberVo;

@Service
@Qualifier("ms")
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberMapper mapper;
	
	@Override
	public String memberJoin(HttpServletRequest request, Model model)
	{
		return "/login/memberJoin";
	}
	
	@Override
	public String memberJoin_ok(MemberVo mvo)
	{
		mapper.memberJoin_ok(mvo);
		return "redirect:/main";
	}
	
}
