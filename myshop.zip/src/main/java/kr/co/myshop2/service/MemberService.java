package kr.co.myshop2.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import kr.co.myshop2.vo.MemberVo;

public interface MemberService {
	
	public String memberJoin(HttpServletRequest request, Model model);

	public String memberJoin_ok(MemberVo mvo);
	
}
