package kr.co.myshop2.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

public interface ProductService {

	public String product(Model model);
	
	public void updateMiddle
	(HttpServletRequest request, PrintWriter out);
	
	public void updateSmall
	(HttpServletRequest request, PrintWriter out);
	
	public String product_ok
	(HttpServletRequest requets) throws IOException;
	
	public void getCode
	(HttpServletRequest request, PrintWriter out);
	
	public String plist
	(HttpServletRequest request, Model model);
	
	public String list
	(HttpServletRequest request, Model model, PrintWriter out, HttpSession session);
	
	public String gumae
	(HttpServletRequest request, Model model, HttpSession session);
	
	public String confirm
	(HttpServletRequest request, HttpSession session, Model model, PrintWriter out);
	
	public String baeCheck
	(HttpServletRequest request, HttpSession session, Model model);
	
	public String gumaelist
	(HttpServletRequest reqeust, Model model, HttpSession session);
	
	public String showBaesongji
	(HttpServletRequest request, HttpSession session, Model model);
	
	public String baesongji
	(HttpServletRequest request, HttpSession session);
	
	public String del
	(HttpServletRequest request);
	
	
}
