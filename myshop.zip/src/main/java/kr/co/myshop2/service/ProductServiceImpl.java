package kr.co.myshop2.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import kr.co.myshop2.mapper.ProductMapper;
import kr.co.myshop2.vo.BaesongVo;
import kr.co.myshop2.vo.BaesongjiVo;
import kr.co.myshop2.vo.ListVo;
import kr.co.myshop2.vo.MemberVo;
import kr.co.myshop2.vo.MiddleVo;
import kr.co.myshop2.vo.ProductVo;
import kr.co.myshop2.vo.SmallVo;

@Service
@Qualifier("ps")
public class ProductServiceImpl implements ProductService {
    
	@Autowired
	private ProductMapper mapper;
	
	@Override
	public String product(Model model)
	{
		model.addAttribute("big", mapper.getBig() );
		return "/product/product";
	}
	
	@Override
	public void updateMiddle
	(HttpServletRequest request, PrintWriter out)
	{
		String bigcode=request.getParameter("bigcode");
		ArrayList<MiddleVo> middle=mapper.updateMiddle(bigcode);
		String str="<option> "+URLEncoder.encode("중분류")+ "</option>";
		for(int i=0;i<middle.size();i++)
		{
		  str=str+"<option value='"+middle.get(i).getCode()+"'> "+URLEncoder.encode(middle.get(i).getName())+" </option>";
		}
		
		out.print(str);
	}
	
	@Override
	public void updateSmall
	(HttpServletRequest request, PrintWriter out)
	{
		String bigmiddlecode=request.getParameter("bigmiddlecode");
		ArrayList<SmallVo> small=mapper.updateSmall(bigmiddlecode);
		
		String str="<option> "+URLEncoder.encode("선택")+"</option>";
		
		for(int i=0;i<small.size();i++)
		{
			str=str+"<option value='"+small.get(i).getCode()+"'> "+URLEncoder.encode(small.get(i).getName())+" </option>";
		}
		
		out.print(str);
	}
	
	@Override
	public String product_ok
	(HttpServletRequest request) throws IOException
	{
		String path=request.getRealPath("resources/pro");
		int size=1920*1080*10;
		MultipartRequest multi=new MultipartRequest(request, path, size, "utf-8", new DefaultFileRenamePolicy() );
		
		String pcode=multi.getParameter("pcode");
		String pimg=multi.getFilesystemName("pimg");
		String title=multi.getParameter("title");
		int price=Integer.parseInt( multi.getParameter("price") );
		int su=Integer.parseInt( multi.getParameter("su") );
		int baesong=Integer.parseInt( multi.getParameter("baesong") );
		int baeday=Integer.parseInt( multi.getParameter("baeday") );
		
		ProductVo pvo=new ProductVo();
		pvo.setPcode(pcode);
		pvo.setPimg(pimg);
		pvo.setTitle(title);
		pvo.setPrice(price);
		pvo.setSu(su);
		pvo.setBaesong(baesong);
		pvo.setBaeday(baeday);
		
		mapper.product_ok(pvo);
		
		return "redirect:/product/product";
	}
	
	@Override
	public void getCode
	(HttpServletRequest request, PrintWriter out)
	{
		String pcode=request.getParameter("pcode");
		out.print( mapper.getCode(pcode) );
	}
	
	@Override
	public String plist
	(HttpServletRequest request, Model model)
	{
		String pcode=request.getParameter("pcode");
		ArrayList<ProductVo> plist=mapper.plist(pcode);
		model.addAttribute("plist", plist);
		
		return "/product/plist";
	}

	@Override
	public String list
	(HttpServletRequest request, Model model, PrintWriter out, HttpSession session)
	{
		String userid=session.getAttribute("userid").toString();
		String title=request.getParameter("title");
		String pcode=request.getParameter("pcode");
		String pimg=request.getParameter("pimg");
		int price=Integer.parseInt(request.getParameter("price"));
		int su=Integer.parseInt(request.getParameter("su"));
		
		ProductVo pvo=new ProductVo();;
		pvo.setUserid(userid);
		pvo.setTitle(title);
		pvo.setPcode(pcode);
		pvo.setPimg(pimg);
		pvo.setPrice(price);
		pvo.setSu(su);
		
		mapper.list(pvo);
		
		return "redirect:/product/plist";
	}
	
	@Override
	public String gumae(HttpServletRequest request, Model model, HttpSession session)
	{
		if (session.getAttribute("userid") == null) 
		{
			return "redirect:/login/login";
		}

		String userid = session.getAttribute("userid").toString();
		
		MemberVo mvo = mapper.getMember(userid);
		model.addAttribute("mvo", mvo);

		ArrayList<ListVo> llist = mapper.mylist(userid);
		model.addAttribute("llist", llist);

		return "/product/gumae";
	}

	
	@Override
	public String confirm
	(HttpServletRequest request, HttpSession session, Model model, PrintWriter out)
	{
		String userid=session.getAttribute("userid").toString();
		
		ArrayList<ListVo> llist=mapper.confirm(userid);
		model.addAttribute("llist", llist);		
		
		return "redirect:/product/baeCheck";
	}
	
	@Override
	public String baeCheck
	(HttpServletRequest request, HttpSession session, Model model)
	{
		String userid=session.getAttribute("userid").toString();
		ArrayList<ListVo> llist=mapper.baeCheck(userid);
		model.addAttribute("llist", llist);
		
		return "/product/baeCheck";
	}
	
	@Override
	public String gumaelist
	(HttpServletRequest request, Model model, HttpSession session)
	{
		try
		{
			String userid=session.getAttribute("userid").toString();
			ArrayList<ProductVo> plist=mapper.gumaelist(userid);
			model.addAttribute("plist", plist);
		}
		catch(NullPointerException e)
		{
			
		}
		
		
		return "/product/gumaelist";
	}
	
	@Override
	public String showBaesongji
	(HttpServletRequest request, HttpSession session, Model model)
	{
		String userid=session.getAttribute("userid").toString();
		mapper.showBaesongji(userid);
		model.addAttribute("bvo", mapper.showBaesongji(userid));
		
		return "/product/showBaesongji";
	}
	
	@Override
	public String baesongji
	(HttpServletRequest request, HttpSession session)
	{
		String userid=session.getAttribute("userid").toString();
		String baesongname=request.getParameter("baesongname");
		String name=request.getParameter("name");
		int phone=Integer.parseInt(request.getParameter("phone"));
		int zipcode=Integer.parseInt(request.getParameter("zipcode"));
		String address=request.getParameter("address");
		String address_etc=request.getParameter("address_etc");
		
		BaesongjiVo bvo=new BaesongjiVo();
		bvo.setUserid(userid);
		bvo.setBaesongname(baesongname);
		bvo.setName(name);
		bvo.setPhone(phone);
		bvo.setZipcode(zipcode);
		bvo.setAddress(address);
		bvo.setAddress_etc(address_etc);
		
		mapper.baesongji(bvo);
		
		return "redirect:/product/showBaesongji";
	}
	
	@Override
	public String del
	(HttpServletRequest request)
	{
		String title=request.getParameter("title");
		
		mapper.del(title);
		
		return "redirect:/product/gumaelist";
	}
	
	
}
