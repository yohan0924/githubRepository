package kr.co.myshop2.service;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.myshop2.mapper.LoginMapper;
import kr.co.myshop2.vo.MemberVo;

@Service
@Qualifier("ls")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginMapper mapper;
	
	@Override
	public String login
	(HttpServletRequest request, Model model)
	{
		String chk=request.getParameter("chk");
		model.addAttribute("chk", chk);
		return "/login/login";
	}
	
	@Override
	public String login_ok
	(MemberVo mvo, HttpSession session)
	{
		MemberVo mvo2=mapper.login_ok(mvo);
		
		if( mvo2 == null )
		{
			return "redirect:/login/login?chk=1";
		}
		else
		{
			session.setAttribute("userid", mvo.getUserid());
			session.setAttribute("name", mvo.getName());
			return "redirect:/main";
		}
	}
	
	@Override
	public void userid_check
	(HttpServletRequest request, PrintWriter out)
	{
		String userid=request.getParameter("userid");
		out.print( mapper.userid_check(userid) );
	}
	
	@Override
	public String logout
	(HttpSession session)
	{
		session.invalidate();
		
		return "redirect:/main";
	}
	
	@Override
	public void find_email
	(HttpServletRequest request, Model model, PrintWriter out)
	{
		String email=request.getParameter("email");
		
		String userid=mapper.find_email(email);
		
		if( userid == null )
		{
			out.print("1");
		}
		else
		{
			out.print(userid);
		}
		
	}
	
	
	
}
