package kr.co.myshop2.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import kr.co.myshop2.vo.MemberVo;

public interface LoginService {

	public String login
	(HttpServletRequest request, Model model);
	
	public String login_ok
	(MemberVo mvo, HttpSession session);
	
	public void userid_check
	(HttpServletRequest request, PrintWriter out);

	public String logout
	(HttpSession session);
	
	public void find_email
	(HttpServletRequest request, Model model, PrintWriter out);
	
}
